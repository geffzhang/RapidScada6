#!/bin/sh
systemctl restart scadaagent6
