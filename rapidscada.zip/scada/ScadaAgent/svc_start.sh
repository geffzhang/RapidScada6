#!/bin/sh
systemctl start scadaagent6
