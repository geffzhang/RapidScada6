#!/bin/sh
systemctl stop scadaagent6
