#!/bin/sh
systemctl restart scadacomm6
