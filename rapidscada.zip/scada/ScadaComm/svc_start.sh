#!/bin/sh
systemctl start scadacomm6
