#!/bin/sh
systemctl stop scadacomm6
