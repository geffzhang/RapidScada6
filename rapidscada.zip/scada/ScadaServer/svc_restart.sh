#!/bin/sh
systemctl restart scadaserver6
