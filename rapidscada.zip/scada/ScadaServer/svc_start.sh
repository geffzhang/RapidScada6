#!/bin/sh
systemctl start scadaserver6
