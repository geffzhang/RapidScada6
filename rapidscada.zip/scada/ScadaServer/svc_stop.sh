#!/bin/sh
systemctl stop scadaserver6
