#!/bin/sh
systemctl start scadaweb6
