#!/bin/sh
systemctl stop scadaweb6
