#!/bin/sh
chmod +x /opt/scada/scadastart.sh
chmod +x /opt/scada/scadastop.sh
chmod +x /opt/scada/ScadaAgent/svc_restart.sh
chmod +x /opt/scada/ScadaAgent/svc_start.sh
chmod +x /opt/scada/ScadaAgent/svc_stop.sh
chmod +x /opt/scada/ScadaComm/svc_restart.sh
chmod +x /opt/scada/ScadaComm/svc_start.sh
chmod +x /opt/scada/ScadaComm/svc_stop.sh
chmod +x /opt/scada/ScadaServer/svc_restart.sh
chmod +x /opt/scada/ScadaServer/svc_start.sh
chmod +x /opt/scada/ScadaServer/svc_stop.sh
chmod +x /opt/scada/ScadaWeb/svc_restart.sh
chmod +x /opt/scada/ScadaWeb/svc_start.sh
chmod +x /opt/scada/ScadaWeb/svc_stop.sh
