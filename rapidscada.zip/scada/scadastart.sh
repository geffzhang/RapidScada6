#!/bin/sh
echo "Starting Rapid SCADA..."
systemctl start scadaagent6
systemctl start scadaserver6
systemctl start scadacomm6
systemctl start scadaweb6
