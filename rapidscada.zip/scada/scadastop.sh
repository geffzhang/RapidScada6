#!/bin/sh
echo "Terminating Rapid SCADA..."
systemctl stop scadaweb6
systemctl stop scadacomm6
systemctl stop scadaserver6
systemctl stop scadaagent6
